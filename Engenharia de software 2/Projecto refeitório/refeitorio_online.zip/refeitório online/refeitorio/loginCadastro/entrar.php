<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="custom/entrar.css">
    <title>Signin</title>
</head>

<body>
    <div class="container">
        <div class="box form-box">

            <?php

            include ("php/config.php");
            if (isset($_POST['submit'])) {
                $username = $_POST['username'];
                $sobrenome = $_POST['sobrenome'];
                $nome = $_POST['nome'];
                $password = $_POST['password'];
                $contacto = $_POST['contacto'];

                $verify_query = mysqli_query($mysqli, "SELECT username FROM usuario WHERE username='$username'");

                if (mysqli_num_rows($verify_query) != 0) {
                    echo "<div class='message'>
                  <p>This email is used, Try another One Please!</p>
              </div> <br>";
                    echo "<a href='javascript:self.history.back()'><button class='btn'>Go Back</button>";
                } else {
                    mysqli_query($mysqli, "INSERT INTO usuario(nome,sobrenome,username,senha,contacto) VALUES('$nome','$sobrenome','$username','$password','$contacto')") or die("Erro Occurred");

                    echo "<div class='message'>
                  <p>Cadastro  Concluido!</p>
              </div> <br>";
                    echo "<a href='entrar.php'><button class='btn'>Entrar Agora</button>";
                }
            }

            ?>

            <header>Registrar</header>
            <form action="" method="post">
                <div class="field input">

                    <label for="Nome">Nome:</label>
                    <input type="text" name="Nome" id="Nome" placeholder="Digite o seu nome" required>
                    <label for="Sobrenone">Sobrenome:</label>
                    <input type="text" name="Sobrenome" id="Sobrenome" placeholder="Digite o seu sobrenome" required>
                    <label for="Nome de Usuário">Nome de Usuário:</label>
                    <input type="text" name="username" id="username" placeholder="Digite o seu nome de usuário"
                        required>
                    <label for="Nome de Usuário">Contacto:</label>
                    <input type="number" name="contacto" id="contacto" placeholder="Digite o seu número" required>
                </div>

                <div class="field input">

                    <label for="password">Senha</label>
                    <input type="password" name="password" id="password" placeholder="Digite a sua senha" required>
                </div>

                <div class="field">
                    <input type="submit" class="btn" name="submit" value="Criar Conta">
                </div>
            </form>

        </div>


    </div>


</body>

</html>