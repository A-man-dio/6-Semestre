<?php 
   session_start();
?>
<!DOCTYPE html>
<html lang="pt">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="custom/login.css">
    <title>Login</title>
</head>

<body>

    <div class="container">
        <div class="box form-box">
        <?php 
             
             include("php/config.php");
             if(isset($_POST['submit'])){
               $username = mysqli_real_escape_string($mysqli,$_POST['username']);
               $password = mysqli_real_escape_string($mysqli,$_POST['password']);

               $result = mysqli_query($mysqli,"SELECT * FROM usuario WHERE username='$username' AND password='$password' ") or die("Select Error");
               $row = mysqli_fetch_assoc($result);

               if(is_array($row) && !empty($row)){
            
                   $_SESSION['username'] = $row['username'];
                   $_SESSION['sobrenome'] = $row['sobrenome'];
                   $_SESSION['nome'] = $row['nome'];
                   $_SESSION['id'] = $row['id'];
                   $_SESSION['contacto'] = $row['contacto'];
               }else{
                   echo "<div class='message'>
                     <p>Username ou Senha errados</p>
                      </div> <br>";
                  echo "<a href='login.php'><button class='btn'>Voltar a tentar</button>";
        
               }
               if(isset($_SESSION['username'])){
                   header("Location: paginaInicial/paginaInicial.php");
               }
             }else {?> 
                        
            <header> Fazer Login</header>
            <form action="" method="post">
                <div class="field input">

                    <label for="Nome">Nome de usuário</label>
                    <input type="text" name="username" id="Nome" placeholder="Digite o seu nome de usuário" required>

                </div>
                <div class="field input">

                    <label for="password">Senha</label>
                    <input type="password" name="password" id="password" placeholder="Digite a sua senha" required>

                </div>
                <div class="field">
                    <input type="submit" class="btn" name="submit" value="Login">
                </div>
                <div class="links">
                    Ainda não tens uma conta ? <a id="linkRegisto" href="entrar.html">Criar uma conta</a>
                </div>
            </form>

        </div>
       <?php } ?>

    </div>





</body>

</html>