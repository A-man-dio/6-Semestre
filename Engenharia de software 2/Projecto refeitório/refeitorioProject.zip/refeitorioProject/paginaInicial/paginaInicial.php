<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ISP Shop</title>
    <link rel="stylesheet" href="paginaInicial.css">
</head>

<body>
    <header>
        <nav id="barraNav">
            <ul id="menuNav">
                <li id="logo">ISP SHOP</li>
            </ul>
        </nav>
    </header>

    <main id="conteudo">
        <h1 id="titulo" class="alinhar">DEIXE O SEU DIA MAIS SABOROSO!</h1>
        <a href=../loginCadastro/login.php id="link"><button id="botaoLogin">Login</button></a>
        <p id="texto1" class="alinhar">Ainda não possui uma conta?</p>
        <a href=../loginCadastro/entrar.php ><p id="texto2" class="alinhar">Cadastre-se</p></a>
    </main>
</body>

</html>