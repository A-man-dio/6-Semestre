<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="paginaInicial.css">
</head>
<body>
    <header>
        <nav id="barraNav">
            <ul id="menuNav">
                <li id="logo">ISP SHOP</li>
            </ul>
        </nav>
    </header>

    <main id="conteudo">
        <h1 id="titulo" class="alinhar">DEIXE O SEU DIA MAIS SABOROSO  
            <?php 
                // Verifica se o nome de usuário está definido na sessão antes de tentar acessá-lo
                if(isset($_SESSION["username"])) {
                    echo $_SESSION["username"];
                } else {
                    echo "!";
                }
            ?> 
        </h1>
        <a href="../loginCadastro/login.html" id="link"><button id="botaoLogin">Login</button></a>
        <p id="texto1" class="alinhar">Ainda não possui uma conta?</p>
        <a href="../loginCadastro/entrar.html"><p id="texto2" class="alinhar">Cadastre-se</p></a>
    </main>
</body>
</html>
