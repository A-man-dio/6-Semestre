export const coordenadas = {
    1: [document.getElementById("1").getBoundingClientRect().left, document.getElementById("1").getBoundingClientRect().top],

    2: [document.getElementById("2").getBoundingClientRect().left, document.getElementById("2").getBoundingClientRect().top],

    3: [document.getElementById("3").getBoundingClientRect().left, document.getElementById("3").getBoundingClientRect().top],

    4: [document.getElementById("4").getBoundingClientRect().left, document.getElementById("4").getBoundingClientRect().top],

    5: [document.getElementById("5").getBoundingClientRect().left, document.getElementById("5").getBoundingClientRect().top],

    6: [document.getElementById("6").getBoundingClientRect().left, document.getElementById("6").getBoundingClientRect().top],

    7: [document.getElementById("7").getBoundingClientRect().left, document.getElementById("7").getBoundingClientRect().top],

    8: [document.getElementById("8").getBoundingClientRect().left, document.getElementById("8").getBoundingClientRect().top],

    9: [document.getElementById("9").getBoundingClientRect().left, document.getElementById("9").getBoundingClientRect().top],

    10: [document.getElementById("10").getBoundingClientRect().left, document.getElementById("10").getBoundingClientRect().top],

    11: [document.getElementById("11").getBoundingClientRect().left, document.getElementById("11").getBoundingClientRect().top],

    12: [document.getElementById("12").getBoundingClientRect().left, document.getElementById("12").getBoundingClientRect().top],

    13: [document.getElementById("13").getBoundingClientRect().left, document.getElementById("13").getBoundingClientRect().top],

    14: [document.getElementById("14").getBoundingClientRect().left, document.getElementById("14").getBoundingClientRect().top],

    15: [document.getElementById("15").getBoundingClientRect().left, document.getElementById("15").getBoundingClientRect().top],

    16: [document.getElementsByClassName("16")[0].getBoundingClientRect().left, document.getElementsByClassName("16")[0].getBoundingClientRect().top],

    17: [document.getElementById("17").getBoundingClientRect().left, document.getElementById("17").getBoundingClientRect().top],

    18: [document.getElementById("18").getBoundingClientRect().left, document.getElementById("18").getBoundingClientRect().top],

    19: [document.getElementById("19").getBoundingClientRect().left, document.getElementById("19").getBoundingClientRect().top],

    20: [document.getElementById("20").getBoundingClientRect().left, document.getElementById("20").getBoundingClientRect().top],

    21: [document.getElementById("21").getBoundingClientRect().left, document.getElementById("21").getBoundingClientRect().top],

    22: [document.getElementById("22").getBoundingClientRect().left, document.getElementById("22").getBoundingClientRect().top],

    23: [document.getElementById("23").getBoundingClientRect().left, document.getElementById("23").getBoundingClientRect().top],

    24: [document.getElementById("24").getBoundingClientRect().left, document.getElementById("24").getBoundingClientRect().top],

    25: [document.getElementById("25").getBoundingClientRect().left, document.getElementById("25").getBoundingClientRect().top],

    26: [document.getElementById("26").getBoundingClientRect().left, document.getElementById("26").getBoundingClientRect().top],

    27: [document.getElementById("27").getBoundingClientRect().left, document.getElementById("27").getBoundingClientRect().top],

    28: [document.getElementById("28").getBoundingClientRect().left, document.getElementById("28").getBoundingClientRect().top],

    29: [document.getElementById("29").getBoundingClientRect().left, document.getElementById("29").getBoundingClientRect().top],

    30: [document.getElementById("30").getBoundingClientRect().left, document.getElementById("30").getBoundingClientRect().top],

    31: [document.getElementById("31").getBoundingClientRect().left, document.getElementById("31").getBoundingClientRect().top],

    32: [document.getElementById("32").getBoundingClientRect().left, document.getElementById("32").getBoundingClientRect().top],

    33: [document.getElementById("33").getBoundingClientRect().left, document.getElementById("33").getBoundingClientRect().top],

    34: [document.getElementById("34").getBoundingClientRect().left, document.getElementById("34").getBoundingClientRect().top],

    35: [document.getElementById("35").getBoundingClientRect().left, document.getElementById("35").getBoundingClientRect().top],

    36: [document.getElementsByClassName("36")[0].getBoundingClientRect().left, document.getElementsByClassName("36")[0].getBoundingClientRect().top],

    37: [document.getElementById("37").getBoundingClientRect().left, document.getElementById("37").getBoundingClientRect().top],

    38: [document.getElementById("38").getBoundingClientRect().left, document.getElementById("38").getBoundingClientRect().top],

    39: [document.getElementById("39").getBoundingClientRect().left, document.getElementById("39").getBoundingClientRect().top],

    40: [document.getElementById("40").getBoundingClientRect().left, document.getElementById("40").getBoundingClientRect().top],

    41: [document.getElementById("41").getBoundingClientRect().left, document.getElementById("41").getBoundingClientRect().top],

    42: [document.getElementById("42").getBoundingClientRect().left, document.getElementById("42").getBoundingClientRect().top],

    43: [document.getElementById("43").getBoundingClientRect().left, document.getElementById("43").getBoundingClientRect().top],

    44: [document.getElementById("44").getBoundingClientRect().left, document.getElementById("44").getBoundingClientRect().top],

    45: [document.getElementById("45").getBoundingClientRect().left, document.getElementById("45").getBoundingClientRect().top],

    46: [document.getElementById("46").getBoundingClientRect().left, document.getElementById("46").getBoundingClientRect().top],

    47: [document.getElementById("47").getBoundingClientRect().left, document.getElementById("47").getBoundingClientRect().top],

    48: [document.getElementById("48").getBoundingClientRect().left, document.getElementById("48").getBoundingClientRect().top],

    49: [document.getElementById("49").getBoundingClientRect().left, document.getElementById("49").getBoundingClientRect().top],

    50: [document.getElementById("50").getBoundingClientRect().left, document.getElementById("50").getBoundingClientRect().top],

    51: [document.getElementById("51").getBoundingClientRect().left, document.getElementById("51").getBoundingClientRect().top],

    52: [document.getElementById("52").getBoundingClientRect().left, document.getElementById("52").getBoundingClientRect().top],

    53: [document.getElementById("53").getBoundingClientRect().left, document.getElementById("53").getBoundingClientRect().top],

    54: [document.getElementById("54").getBoundingClientRect().left, document.getElementById("54").getBoundingClientRect().top],

    55: [document.getElementById("55").getBoundingClientRect().left, document.getElementById("55").getBoundingClientRect().top],

    56: [document.getElementsByClassName("56")[0].getBoundingClientRect().left, document.getElementsByClassName("56")[0].getBoundingClientRect().top],

    57: [document.getElementById("57").getBoundingClientRect().left, document.getElementById("57").getBoundingClientRect().top],

    58: [document.getElementById("58").getBoundingClientRect().left, document.getElementById("58").getBoundingClientRect().top],

    59: [document.getElementById("59").getBoundingClientRect().left, document.getElementById("59").getBoundingClientRect().top],

    60: [document.getElementById("60").getBoundingClientRect().left, document.getElementById("60").getBoundingClientRect().top],

    61: [document.getElementById("61").getBoundingClientRect().left, document.getElementById("61").getBoundingClientRect().top],

    62: [document.getElementById("62").getBoundingClientRect().left, document.getElementById("62").getBoundingClientRect().top],

    63: [document.getElementById("63").getBoundingClientRect().left, document.getElementById("63").getBoundingClientRect().top],

    64: [document.getElementById("64").getBoundingClientRect().left, document.getElementById("64").getBoundingClientRect().top],

    65: [document.getElementById("65").getBoundingClientRect().left, document.getElementById("65").getBoundingClientRect().top],

    66: [document.getElementById("66").getBoundingClientRect().left, document.getElementById("66").getBoundingClientRect().top],

    67: [document.getElementById("67").getBoundingClientRect().left, document.getElementById("67").getBoundingClientRect().top],

    68: [document.getElementById("68").getBoundingClientRect().left, document.getElementById("68").getBoundingClientRect().top],

    69: [document.getElementById("69").getBoundingClientRect().left, document.getElementById("69").getBoundingClientRect().top],

    70: [document.getElementById("70").getBoundingClientRect().left, document.getElementById("70").getBoundingClientRect().top],

    71: [document.getElementById("71").getBoundingClientRect().left, document.getElementById("71").getBoundingClientRect().top],

    72: [document.getElementById("72").getBoundingClientRect().left, document.getElementById("72").getBoundingClientRect().top],

    73: [document.getElementById("73").getBoundingClientRect().left, document.getElementById("73").getBoundingClientRect().top],

    74: [document.getElementById("74").getBoundingClientRect().left, document.getElementById("74").getBoundingClientRect().top],

    75: [document.getElementById("75").getBoundingClientRect().left, document.getElementById("75").getBoundingClientRect().top],

    76: [document.getElementsByClassName("76")[0].getBoundingClientRect().left, document.getElementsByClassName("76")[0].getBoundingClientRect().top],

    77: [document.getElementById("77").getBoundingClientRect().left, document.getElementById("77").getBoundingClientRect().top],

    78: [document.getElementById("78").getBoundingClientRect().left, document.getElementById("78").getBoundingClientRect().top],

    79: [document.getElementById("79").getBoundingClientRect().left, document.getElementById("79").getBoundingClientRect().top],

    80: [document.getElementById("80").getBoundingClientRect().left, document.getElementById("80").getBoundingClientRect().top],

    //100 entrada vermelha
    100: [document.getElementById("100").getBoundingClientRect().left, document.getElementById("100").getBoundingClientRect().top],

    101: [document.getElementById("101").getBoundingClientRect().left, document.getElementById("101").getBoundingClientRect().top],

    102: [document.getElementById("102").getBoundingClientRect().left, document.getElementById("102").getBoundingClientRect().top],

    103: [document.getElementById("103").getBoundingClientRect().left, document.getElementById("103").getBoundingClientRect().top],

    104: [document.getElementById("104").getBoundingClientRect().left, document.getElementById("104").getBoundingClientRect().top],

    105: [document.getElementById("105").getBoundingClientRect().left, document.getElementById("105").getBoundingClientRect().top],

    106: [document.getElementById("106").getBoundingClientRect().left, document.getElementById("106").getBoundingClientRect().top],

    107: [document.getElementById("107").getBoundingClientRect().left, document.getElementById("107").getBoundingClientRect().top],

    108: [document.getElementById("108").getBoundingClientRect().left, document.getElementById("108").getBoundingClientRect().top],

    109: [document.getElementById("109").getBoundingClientRect().left, document.getElementById("109").getBoundingClientRect().top],

    //200 entrada azul

    200: [document.getElementById("200").getBoundingClientRect().left, document.getElementById("200").getBoundingClientRect().top],

    201: [document.getElementById("201").getBoundingClientRect().left, document.getElementById("201").getBoundingClientRect().top],

    202: [document.getElementById("202").getBoundingClientRect().left, document.getElementById("202").getBoundingClientRect().top],

    203: [document.getElementById("203").getBoundingClientRect().left, document.getElementById("203").getBoundingClientRect().top],

    204: [document.getElementById("204").getBoundingClientRect().left, document.getElementById("204").getBoundingClientRect().top],

    205: [document.getElementById("205").getBoundingClientRect().left, document.getElementById("205").getBoundingClientRect().top],

    206: [document.getElementById("206").getBoundingClientRect().left, document.getElementById("206").getBoundingClientRect().top],

    207: [document.getElementById("207").getBoundingClientRect().left, document.getElementById("207").getBoundingClientRect().top],

    208: [document.getElementById("208").getBoundingClientRect().left, document.getElementById("208").getBoundingClientRect().top],

    209: [document.getElementById("209").getBoundingClientRect().left, document.getElementById("209").getBoundingClientRect().top],



    //300 entrada verde

    300: [document.getElementById("300").getBoundingClientRect().left, document.getElementById("300").getBoundingClientRect().top],

    301: [document.getElementById("301").getBoundingClientRect().left, document.getElementById("301").getBoundingClientRect().top],

    302: [document.getElementById("302").getBoundingClientRect().left, document.getElementById("302").getBoundingClientRect().top],

    303: [document.getElementById("303").getBoundingClientRect().left, document.getElementById("303").getBoundingClientRect().top],

    304: [document.getElementById("304").getBoundingClientRect().left, document.getElementById("304").getBoundingClientRect().top],

    305: [document.getElementById("305").getBoundingClientRect().left, document.getElementById("305").getBoundingClientRect().top],

    306: [document.getElementById("306").getBoundingClientRect().left, document.getElementById("306").getBoundingClientRect().top],

    307: [document.getElementById("307").getBoundingClientRect().left, document.getElementById("307").getBoundingClientRect().top],

    308: [document.getElementById("308").getBoundingClientRect().left, document.getElementById("308").getBoundingClientRect().top],

    309: [document.getElementById("309").getBoundingClientRect().left, document.getElementById("309").getBoundingClientRect().top],

    //400 entrada amarela

    400: [document.getElementById("400").getBoundingClientRect().left, document.getElementById("400").getBoundingClientRect().top],

    401: [document.getElementById("401").getBoundingClientRect().left, document.getElementById("401").getBoundingClientRect().top],

    402: [document.getElementById("402").getBoundingClientRect().left, document.getElementById("402").getBoundingClientRect().top],

    403: [document.getElementById("403").getBoundingClientRect().left, document.getElementById("403").getBoundingClientRect().top],

    404: [document.getElementById("404").getBoundingClientRect().left, document.getElementById("404").getBoundingClientRect().top],

    405: [document.getElementById("405").getBoundingClientRect().left, document.getElementById("405").getBoundingClientRect().top],

    406: [document.getElementById("406").getBoundingClientRect().left, document.getElementById("406").getBoundingClientRect().top],

    407: [document.getElementById("407").getBoundingClientRect().left, document.getElementById("407").getBoundingClientRect().top],

    408: [document.getElementById("408").getBoundingClientRect().left, document.getElementById("408").getBoundingClientRect().top],

    409: [document.getElementById("409").getBoundingClientRect().left, document.getElementById("409").getBoundingClientRect().top],


    //base position

    //red

    500: [document.getElementsByClassName("500")[0].getBoundingClientRect().left, document.getElementsByClassName("500")[0].getBoundingClientRect().top],

    501: [document.getElementsByClassName("501")[0].getBoundingClientRect().left, document.getElementsByClassName("501")[0].getBoundingClientRect().top],

    502: [document.getElementsByClassName("502")[0].getBoundingClientRect().left, document.getElementsByClassName("502")[0].getBoundingClientRect().top],

    503: [document.getElementsByClassName("503")[0].getBoundingClientRect().left, document.getElementsByClassName("503")[0].getBoundingClientRect().top],

    //green

    600: [document.getElementsByClassName("600")[0].getBoundingClientRect().left, document.getElementsByClassName("600")[0].getBoundingClientRect().top],

    601: [document.getElementsByClassName("601")[0].getBoundingClientRect().left, document.getElementsByClassName("601")[0].getBoundingClientRect().top],

    602: [document.getElementsByClassName("602")[0].getBoundingClientRect().left, document.getElementsByClassName("602")[0].getBoundingClientRect().top],

    603: [document.getElementsByClassName("603")[0].getBoundingClientRect().left, document.getElementsByClassName("603")[0].getBoundingClientRect().top],

    //blue

    700: [document.getElementsByClassName("700")[0].getBoundingClientRect().left, document.getElementsByClassName("700")[0].getBoundingClientRect().top],

    701: [document.getElementsByClassName("701")[0].getBoundingClientRect().left, document.getElementsByClassName("701")[0].getBoundingClientRect().top],

    702: [document.getElementsByClassName("702")[0].getBoundingClientRect().left, document.getElementsByClassName("702")[0].getBoundingClientRect().top],

    703: [document.getElementsByClassName("703")[0].getBoundingClientRect().left, document.getElementsByClassName("703")[0].getBoundingClientRect().top],


    //yellow

    800: [document.getElementsByClassName("800")[0].getBoundingClientRect().left, document.getElementsByClassName("800")[0].getBoundingClientRect().top],

    801: [document.getElementsByClassName("801")[0].getBoundingClientRect().left, document.getElementsByClassName("801")[0].getBoundingClientRect().top],

    802: [document.getElementsByClassName("802")[0].getBoundingClientRect().left, document.getElementsByClassName("802")[0].getBoundingClientRect().top],

    803: [document.getElementsByClassName("803")[0].getBoundingClientRect().left, document.getElementsByClassName("803")[0].getBoundingClientRect().top]

};

export const step_lenght = 25.5;

export const base_positions = {
    P1: [500, 501, 502, 503],  //red
    P2: [600, 601, 602, 603], //green
    P3: [700, 701, 702, 703] , //blue
    P4: [800, 801, 802, 803]   //yellow
}

export const start_positions = {
    P1: 1,
    P2: 61,
    P3: 21,
    P4: 41
}

export const home_entrance = {
    P1: [100, 101, 102, 103, 104, 105, 106, 107, 108],
    P2: [300, 301, 302, 303, 304, 305, 306, 307, 308],
    P3: [200, 201, 202, 203, 204, 205, 206, 207, 208],
    P4: [400, 401, 402, 403, 404, 405, 406, 407, 408]
}

export const home_positions = {
    P1: 109,
    P2: 309,
    P3: 209,
    P4: 409
}

export const turning_points = {  //fichas
    P1: 76,
    P2: 56,
    P3: 16,
    P4: 36
}

export const safe_positions = [1, 71, 11, 61, 21, 51, 31, 41];

export const state = {
    dice_not_rolled: "dice not rolled",
    dice_rolled: "dice rolled"
}

export const choose = {
    chose_dice: "chose_dice",
    not_chose_dice: "not chose dice"
}


export const players = ["P1", "P2", "P3", "P4"];

export const playersB = ["red-box", "green-box", "blue-box", "P4-box"];
