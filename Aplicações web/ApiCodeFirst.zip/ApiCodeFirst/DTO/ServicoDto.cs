﻿namespace DTO
{
    public class ServicoDto
    {
        public int ServicoId { get; set; }
        public string Descricao { get; set; }
        public decimal Preco { get; set; }
    }
}
