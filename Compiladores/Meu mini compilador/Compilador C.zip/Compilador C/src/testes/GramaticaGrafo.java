/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testes;

/**
 *
 * @author ernestoamandio
 */
public class GramaticaGrafo {
    
    public static Grafo gerarGrafo() {
        Grafo grafo = new Grafo();

        String[] gramatica = {
            "programa ::= decl_list",
            "decl_list ::= decl",
            "decl ::= type_spec ID decl_1",
            "decl_1 ::= var_decl decl/|fun_decl decl",
            "var_decl ::= ; /| [ INT_LIT ] ; /| = exp ; /| ID var_decl",
            "fun_decl ::= ( params ) fun_decl_1",
            "type_spec ::= void /| float /| char /| int /| double  ",
            "fun_decl_1 ::= com_stmt",
            "params ::= void /| param /| vazio",
            "param ::= type_spec ID param_1",
            "param_1 ::= [ ] param_2 /| , type_spec ID param_1 /| vazio",
            "param_2 ::= , type_spec ID param_1 /| vazio",
            "stmt ::= exp_stmt /| com_stmt /| if_stmt /| while_stmt /| return_stmt /| break_stmt /| for_stmt /|"
                + " printf_stmt /| scanf_stmt /| do_stmt ",
            "exp_stmt ::= ; /| exp ;",
            "com_stmt ::= { content }",
            "content ::= local_decls content /| stmt content /| vazio",
            "do_stmt ::= do stmt while ( exp ) ;",
            "while_stmt ::= while ( exp ) stmt",
            "local_decls ::= type_spec ID local_decl_1 /| vazio ",
            "local_decl_1 ::= ; local_decls /| [ ] ; local_decls /| = exp ; local_decls , ID local_decl_2",
            "local_decl_2 ::= ; /| , ID local_decl_1",
            "if_stmt ::= if ( exp ) stmt if_stmt_1",
            "if_stmt_1 ::= vazio /| else stmt",
            "for_stmt ::= for ( for_stmt_1 ; exp ; exp ) stmt ",
            "for_stmt_1 ::= type_spec ID = exp /| exp",
            "return_stmt ::= return return_stmt_1",
            "return_stmt_1 ::= ; /| exp ;",
            "break_stmt ::= break ;",
            "exp ::= ID exp_1 exp_3 /| + exp exp_3 /| - exp exp_3 /| ! exp exp_3 /| FLOAT_LIT exp_3 /| CHAR_LIT exp_3 /| INT_LIT exp_3",
            "exp_3 ::= || exp exp_3 /| = exp exp_3 /| == exp exp_3 /| <= exp exp_3 /| < exp exp_3 /| > exp exp_3 /| > = exp exp_3 /| && exp exp_3"
                + " /| + exp exp_3 /| - exp exp_3 /| % exp exp_3 /| * exp exp_3 /| ~ exp exp_3 /| += exp exp_3 /| -= exp exp_3 | vazio",
            "exp_1 ::= [ exp ] exp_2 /| . sizeof /| ( args ) /| ++ /| -- /| vazio",
            "exp_2 ::= = exp /| vazio",
            "arg_list_1 ::= , exp arg_list_1 /| vazio",
            "args ::= exp arg_list_1 /| vazio"
        };

        for (String simbolo : gramatica) {
            String[] partes = simbolo.split("::=");
            String origemId = partes[0].trim();
            String[] destinos = partes[1].split("\\/");

            Vertice origem = grafo.getVertice(origemId);
            if (origem == null) {
                origem = new Vertice(origemId);
                grafo.adicionarVertice(origem);
            }

            for (String destino : destinos) {
                String[] destinosIndividuais = destino.trim().split(" ");
                for (String destinoId : destinosIndividuais) {
                    destinoId = destinoId.trim();
                    Vertice destinoVertice = grafo.getVertice(destinoId);
                    if (destinoVertice == null) {
                        destinoVertice = new Vertice(destinoId);
                        grafo.adicionarVertice(destinoVertice);
                    }
                    grafo.adicionarAresta(origem, destinoVertice);
                }
            }
        }

        return grafo;
    }

    public static void main(String[] args) {
        Grafo grafo = gerarGrafo();
        grafo.mostrarGrafo();
    }
}
