package analisador;

/**
 *
 * @author Derby Cândido
 */
public class TOKEN {

    public int linha;
    public String token;
    public String tipo;
}
